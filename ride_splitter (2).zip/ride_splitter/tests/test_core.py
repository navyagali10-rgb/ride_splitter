import json
import tempfile
import unittest
from pathlib import Path

from core.importer import import_csv_text
from core.models import Passenger
from core.splitter import build_ride, compute_shares, largest_remainder
from core.storage import Store
from core.validation import ValidationError, parse_date, parse_money


def pax(*pairs):
    return [Passenger(name=n, value=v) for n, v in pairs]


def ride(**kw):
    base = dict(date="2026-01-05", route="A to B", category="commute", fare="100", extras="",
                split_mode="equal", payer="A", passengers=pax(("A", None), ("B", None), ("C", None)))
    base.update(kw)
    return build_ride(**base)


class SplitterTests(unittest.TestCase):
    def test_equal_sums_exactly(self):
        for total in (1, 2, 100, 10001, 5_000_000):
            for n in range(2, 11):
                self.assertEqual(sum(largest_remainder(total, [1] * n)), total)

    def test_hundred_three_ways(self):
        self.assertEqual(sorted(largest_remainder(10000, [1, 1, 1])), [3333, 3333, 3334])

    def test_weighted(self):
        r = ride(fare="90", split_mode="weighted", passengers=pax(("A", 2), ("B", 1)))
        self.assertEqual([p.share_cents for p in r.passengers], [6000, 3000])

    def test_percent_odd(self):
        r = ride(split_mode="percent", passengers=pax(("A", 33.33), ("B", 33.33), ("C", 33.34)))
        self.assertEqual(sum(p.share_cents for p in r.passengers), 10000)
        self.assertEqual(r.passengers[2].share_cents, 3334)

    def test_fixed_remainder(self):
        r = ride(fare="100", split_mode="fixed", passengers=pax(("A", None), ("B", 30), ("C", 20)))
        self.assertEqual([p.share_cents for p in r.passengers], [5000, 3000, 2000])

    def test_extras_included(self):
        r = ride(fare="100", extras="20", passengers=pax(("A", None), ("B", None)))
        self.assertEqual(r.total_cents, 12000)
        self.assertEqual(sum(p.share_cents for p in r.passengers), 12000)

    def test_payer_is_settled(self):
        r = ride()
        self.assertTrue(r.passengers[0].settled)
        self.assertFalse(r.passengers[1].settled)


class ValidationTests(unittest.TestCase):
    def test_money(self):
        self.assertEqual(parse_money("1,250.50"), 125050)
        for bad in ("", "abc", "-5", "0", "1.234", "nan", "1e9", "99999999"):
            with self.assertRaises(ValidationError, msg=bad):
                parse_money(bad)

    def test_date(self):
        with self.assertRaises(ValidationError):
            parse_date("2999-01-01")
        with self.assertRaises(ValidationError):
            parse_date("12/05/2026")

    def test_passenger_rules(self):
        with self.assertRaises(ValidationError):
            ride(passengers=pax(("A", None)))
        with self.assertRaises(ValidationError):
            ride(passengers=pax(("A", None), ("a", None)))
        with self.assertRaises(ValidationError):
            ride(split_mode="percent", passengers=pax(("A", 60), ("B", 50)))
        with self.assertRaises(ValidationError):
            ride(split_mode="fixed", passengers=pax(("A", 80), ("B", 80)))
        with self.assertRaises(ValidationError):
            ride(payer="Zed")


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.path = self.dir / "rides.json"

    def test_missing_file_created(self):
        s = Store(self.path)
        self.assertEqual(s.rides, [])
        self.assertTrue(self.path.exists())

    def test_corrupt_file_backed_up(self):
        self.path.write_text("{not json", encoding="utf-8")
        s = Store(self.path)
        self.assertEqual(s.rides, [])
        self.assertEqual(len(list(self.dir.glob("*.corrupt-*"))), 1)

    def test_roundtrip(self):
        s = Store(self.path)
        s.add(ride())
        again = Store(self.path)
        self.assertEqual(len(again.rides), 1)
        self.assertEqual(again.rides[0].total_cents, 10000)

    def test_bad_record_skipped(self):
        s = Store(self.path)
        s.add(ride())
        data = json.loads(self.path.read_text())
        data["rides"].append({"id": 9})
        self.path.write_text(json.dumps(data))
        again = Store(self.path)
        self.assertEqual(len(again.rides), 1)
        self.assertEqual(len(again.notes), 1)


class ImporterTests(unittest.TestCase):
    def test_row_errors(self):
        text = open(Path(__file__).parent.parent / "data" / "sample_bad.csv", encoding="utf-8").read()
        rides, errors = import_csv_text(text)
        self.assertEqual(len(rides), 1)
        self.assertEqual(len(errors), 9)

    def test_missing_columns(self):
        rides, errors = import_csv_text("a,b\n1,2\n")
        self.assertEqual(rides, [])
        self.assertIn("Missing", errors[0]["error"])


if __name__ == "__main__":
    unittest.main()
