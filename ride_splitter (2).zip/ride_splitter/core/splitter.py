"""Split engine. Uses exact fractions and the largest-remainder method so shares ALWAYS sum to the total."""
from __future__ import annotations

from decimal import Decimal
from fractions import Fraction
from math import floor

from . import validation as v
from .models import Passenger, Ride


def largest_remainder(total_cents: int, weights: list) -> list:
    """Distribute total_cents proportionally to weights with no lost or invented cents."""
    fr = [Fraction(str(w)) for w in weights]
    whole = sum(fr)
    exact = [Fraction(total_cents) * w / whole for w in fr]
    shares = [floor(e) for e in exact]
    leftover = total_cents - sum(shares)
    order = sorted(range(len(shares)), key=lambda i: (-(exact[i] - shares[i]), i))
    for i in order[:leftover]:
        shares[i] += 1
    return shares


def compute_shares(total_cents: int, mode: str, passengers: list) -> list:
    n = len(passengers)
    if mode == "equal":
        return largest_remainder(total_cents, [1] * n)
    if mode in ("weighted", "percent"):
        return largest_remainder(total_cents, [p.value for p in passengers])
    if mode == "fixed":
        fixed = [None if p.value is None else int(Decimal(str(p.value)) * 100) for p in passengers]
        remainder = total_cents - sum(f for f in fixed if f is not None)
        flex = [i for i, f in enumerate(fixed) if f is None]
        shares = [f if f is not None else 0 for f in fixed]
        if flex:
            for i, s in zip(flex, largest_remainder(remainder, [1] * len(flex))):
                shares[i] = s
        return shares
    raise v.ValidationError(f"Unknown split mode '{mode}'.")


def build_ride(*, date, route, category, fare, extras, split_mode, payer,
               passengers: list, notes="", ride_id=0, settled_names=()) -> Ride:
    """Validate raw field values (text is fine) and return a Ride with computed shares."""
    fare_c = v.parse_money(fare, field="Fare")
    extras_c = v.parse_money(extras, field="Extras", allow_zero=True, allow_blank=True)
    mode = v.parse_mode(split_mode)
    pax = [Passenger(name=v.parse_text(p.name, field="Passenger name", max_len=40, allow_blank=True),
                     value=p.value) for p in passengers]
    v.validate_passengers(mode, pax, fare_c + extras_c)
    payer = v.parse_text(payer, field="Payer", max_len=40)
    if payer.lower() not in {p.name.lower() for p in pax}:
        raise v.ValidationError(f"The payer '{payer}' must be one of the passengers.")
    payer = next(p.name for p in pax if p.name.lower() == payer.lower())
    ride_date = v.parse_date(date)
    route = v.parse_text(route, field="Route")
    category = v.parse_category(category)
    notes = v.parse_text(notes, field="Notes", max_len=200, allow_blank=True)

    shares = compute_shares(fare_c + extras_c, mode, pax)
    done = {n.lower() for n in settled_names}
    for p, s in zip(pax, shares):
        p.share_cents = s
        p.settled = p.name == payer or p.name.lower() in done
    if mode == "equal":
        for p in pax:
            p.value = None
    assert sum(shares) == fare_c + extras_c
    return Ride(id=ride_id, date=ride_date, route=route, category=category, fare_cents=fare_c,
                extras_cents=extras_c, split_mode=mode, payer=payer, passengers=pax, notes=notes)
