"""JSON persistence with corruption recovery."""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from .models import DATA_FILE, Ride


class Store:
    def __init__(self, path=DATA_FILE):
        self.path = Path(path)
        self.rides: list = []
        self.notes: list = []
        self.load()

    # ---- load / save -------------------------------------------------
    def load(self) -> None:
        self.notes = []
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict) or not isinstance(raw.get("rides"), list):
                raise ValueError("unexpected file structure")
        except FileNotFoundError:
            self.rides = []
            self.save()
            self.notes.append("No data file found, so a new empty one was created.")
            return
        except (json.JSONDecodeError, ValueError) as exc:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            backup = self.path.with_suffix(f".corrupt-{stamp}.json")
            try:
                os.replace(self.path, backup)
            except OSError:
                pass
            self.rides = []
            self.save()
            self.notes.append(f"Data file was unreadable ({exc}). It was moved to {backup.name} and a clean file was created.")
            return

        loaded = []
        for i, rec in enumerate(raw["rides"]):
            try:
                ride = Ride.from_dict(rec)
                if sum(p.share_cents for p in ride.passengers) != ride.total_cents:
                    raise ValueError("shares do not add up to the total")
                loaded.append(ride)
            except (KeyError, TypeError, ValueError) as exc:
                self.notes.append(f"Skipped record #{i + 1}: {exc}")
        self.rides = loaded

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        payload = {"version": 1, "rides": [r.to_dict() for r in self.rides]}
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.path)

    # ---- operations --------------------------------------------------
    def next_id(self) -> int:
        return max((r.id for r in self.rides), default=0) + 1

    def add(self, ride: Ride) -> Ride:
        ride.id = self.next_id()
        self.rides.append(ride)
        self.save()
        return ride

    def add_many(self, rides: list) -> int:
        for r in rides:
            r.id = self.next_id()
            self.rides.append(r)
        self.save()
        return len(rides)

    def get(self, ride_id: int):
        return next((r for r in self.rides if r.id == ride_id), None)

    def delete(self, ride_id: int) -> bool:
        before = len(self.rides)
        self.rides = [r for r in self.rides if r.id != ride_id]
        self.save()
        return len(self.rides) < before

    def set_settled(self, ride_id: int, name: str, settled: bool) -> bool:
        ride = self.get(ride_id)
        if not ride:
            return False
        for p in ride.passengers:
            if p.name == name and p.name != ride.payer:
                p.settled = settled
                self.save()
                return True
        return False
