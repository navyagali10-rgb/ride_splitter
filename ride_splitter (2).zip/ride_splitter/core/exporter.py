"""Markdown / plain-text audit / CSV exports."""
from __future__ import annotations

import csv
import io
from datetime import datetime

from .importer import COLUMNS
from .models import EXPORT_DIR, money
from .summary import summarize


def _pax_field(r) -> str:
    parts = []
    for p in r.passengers:
        if p.value is None:
            parts.append(p.name)
        else:
            parts.append(f"{p.name}:{p.value:g}")
    return ";".join(parts)


def to_csv(rides) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(COLUMNS)
    for r in sorted(rides, key=lambda r: r.id):
        settled = ";".join(p.name for p in r.passengers if p.settled and p.name != r.payer)
        w.writerow([r.date, r.route, r.category, f"{r.fare_cents / 100:.2f}", f"{r.extras_cents / 100:.2f}",
                    r.split_mode, r.payer, _pax_field(r), settled, r.notes])
    return buf.getvalue()


def to_markdown(rides) -> str:
    s = summarize(rides)
    lines = ["# Ride Share Cost Splitter: Summary Report", "",
             f"Generated {datetime.now():%Y-%m-%d %H:%M}", "",
             "## Totals", "",
             f"- Rides: **{s['count']}**",
             f"- Total spent: **{money(s['total_cents'])}**",
             f"- Average fare: **{money(s['avg_fare_cents'])}**",
             f"- Average share per passenger: **{money(s['avg_share_cents'])}**",
             f"- Unsettled: **{money(s['unsettled_cents'])}**",
             f"- Trend: {s['trend']}", "", "## Monthly spend", "",
             "| Month | Total |", "|---|---:|"]
    lines += [f"| {m} | {money(c)} |" for m, c in s["monthly"].items()]
    lines += ["", "## By category", "", "| Category | Total |", "|---|---:|"]
    lines += [f"| {k} | {money(c)} |" for k, c in s["by_category"].items()]
    lines += ["", "## Who owes what", "", "| Person | Owes |", "|---|---:|"]
    lines += [f"| {k} | {money(c)} |" for k, c in s["owes"].items()] or ["| nobody | - |"]
    lines += ["", "## Warnings", ""]
    lines += [f"- [{w['level']}] {w['text']}" for w in s["warnings"]] or ["- None"]
    lines += ["", "## Rides", "", "| # | Date | Route | Total | Split | Paid by | Open |", "|---:|---|---|---:|---|---|---:|"]
    for r in sorted(rides, key=lambda r: r.id):
        lines.append(f"| {r.id} | {r.date} | {r.route} | {money(r.total_cents)} | {r.split_mode} | {r.payer} | {money(r.unsettled_cents)} |")
    return "\n".join(lines) + "\n"


def to_audit_text(rides) -> str:
    lines = [f"RIDE SPLIT AUDIT LOG - generated {datetime.now():%Y-%m-%d %H:%M:%S}", "=" * 60]
    for r in sorted(rides, key=lambda r: r.id):
        lines.append(f"Ride #{r.id} | {r.date} | {r.route} | {r.category}")
        lines.append(f"  fare {money(r.fare_cents)} + extras {money(r.extras_cents)} = {money(r.total_cents)} | mode {r.split_mode} | paid by {r.payer}")
        for p in r.passengers:
            state = "paid driver" if p.name == r.payer else ("settled" if p.settled else "OWES")
            lines.append(f"    {p.name:<20}{money(p.share_cents):>14}  {state}")
        check = "OK" if sum(p.share_cents for p in r.passengers) == r.total_cents else "MISMATCH"
        lines.append(f"  check: shares sum to total -> {check}")
        lines.append("-" * 60)
    return "\n".join(lines) + "\n"


def export_file(rides, fmt: str):
    """fmt: markdown | text | csv. Returns the written Path."""
    EXPORT_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    makers = {"markdown": ("md", to_markdown), "text": ("txt", to_audit_text), "csv": ("csv", to_csv)}
    ext, fn = makers[fmt]
    path = EXPORT_DIR / f"rides-{stamp}.{ext}"
    path.write_text(fn(rides), encoding="utf-8")
    return path


def write_error_log(errors, name="import-errors"):
    EXPORT_DIR.mkdir(exist_ok=True)
    path = EXPORT_DIR / f"{name}-{datetime.now():%Y%m%d-%H%M%S}.txt"
    path.write_text("\n".join(f"Row {e['row']}: {e['error']}" for e in errors) + "\n", encoding="utf-8")
    return path
