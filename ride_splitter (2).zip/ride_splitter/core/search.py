from __future__ import annotations


def search_rides(rides, keyword="", category="", date_from="", date_to="", unsettled_only=False):
    kw = keyword.strip().lower()
    out = []
    for r in rides:
        if category and category != "all" and r.category != category:
            continue
        if date_from and r.date < date_from:
            continue
        if date_to and r.date > date_to:
            continue
        if unsettled_only and r.unsettled_cents == 0:
            continue
        if kw:
            hay = " ".join([r.route, r.notes, r.payer, r.category, *[p.name for p in r.passengers]]).lower()
            if kw not in hay:
                continue
        out.append(r)
    return sorted(out, key=lambda r: (r.date, r.id), reverse=True)
