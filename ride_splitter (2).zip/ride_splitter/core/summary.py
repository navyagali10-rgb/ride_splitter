from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from statistics import median

from .models import money

HIGH_FARE_CENTS = 500_000     # 5,000.00
LOW_FARE_CENTS = 2_000        # 20.00
STALE_DAYS = 14


def summarize(rides, today=None) -> dict:
    today = today or date.today()
    n = len(rides)
    pax_entries = [p for r in rides for p in r.passengers]
    total = sum(r.total_cents for r in rides)
    monthly, by_cat = defaultdict(int), defaultdict(int)
    owes, owed = defaultdict(int), defaultdict(int)
    for r in rides:
        monthly[r.date[:7]] += r.total_cents
        by_cat[r.category] += r.total_cents
        for p in r.passengers:
            if not p.settled and p.name != r.payer:
                owes[p.name] += p.share_cents
                owed[r.payer] += p.share_cents
    monthly = dict(sorted(monthly.items()))
    months = list(monthly.values())
    if len(months) >= 2 and months[-2]:
        pct = (months[-1] - months[-2]) / months[-2] * 100
        trend = f"{'Up' if pct >= 0 else 'Down'} {abs(pct):.0f}% vs the previous month"
    else:
        trend = "Not enough months yet for a trend"
    return {
        "count": n,
        "total_cents": total,
        "avg_fare_cents": round(total / n) if n else 0,
        "avg_share_cents": round(sum(p.share_cents for p in pax_entries) / len(pax_entries)) if pax_entries else 0,
        "unsettled_cents": sum(r.unsettled_cents for r in rides),
        "monthly": monthly,
        "by_category": dict(sorted(by_cat.items(), key=lambda kv: -kv[1])),
        "owes": dict(sorted(owes.items(), key=lambda kv: -kv[1])),
        "owed": dict(sorted(owed.items(), key=lambda kv: -kv[1])),
        "top_owes": max(owes.items(), key=lambda kv: kv[1]) if owes else None,
        "top_owed": max(owed.items(), key=lambda kv: kv[1]) if owed else None,
        "trend": trend,
        "warnings": warnings(rides, today),
    }


def warnings(rides, today=None) -> list:
    today = today or date.today()
    out = []
    med = median([r.total_cents for r in rides]) if len(rides) >= 5 else None
    for r in sorted(rides, key=lambda r: r.id):
        tag = f"Ride #{r.id} ({r.date}, {r.route})"
        if r.total_cents >= HIGH_FARE_CENTS or (med and r.total_cents > 3 * med):
            out.append({"level": "warn", "text": f"{tag}: unusually high total of {money(r.total_cents)}."})
        if r.total_cents < LOW_FARE_CENTS:
            out.append({"level": "info", "text": f"{tag}: very small total of {money(r.total_cents)}. Check it is not a typo."})
        if r.fare_cents and r.extras_cents / r.fare_cents > 0.30:
            out.append({"level": "info", "text": f"{tag}: extras are {r.extras_cents / r.fare_cents:.0%} of the fare."})
        if r.unsettled_cents:
            age = (today - datetime.strptime(r.date, "%Y-%m-%d").date()).days
            if age > STALE_DAYS:
                out.append({"level": "alert", "text": f"{tag}: {money(r.unsettled_cents)} still unsettled after {age} days."})
    rank = {"alert": 0, "warn": 1, "info": 2}
    return sorted(out, key=lambda w: rank[w["level"]])
