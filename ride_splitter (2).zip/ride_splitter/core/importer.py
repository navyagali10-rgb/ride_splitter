"""Bulk CSV import with a row-by-row error log. The format is the same one the CSV export writes."""
from __future__ import annotations

import csv
import io

from .models import Passenger
from .splitter import build_ride
from .validation import ValidationError, parse_number

COLUMNS = ["date", "route", "category", "fare", "extras", "split_mode", "payer",
           "passengers", "settled", "notes"]
REQUIRED = ["date", "route", "category", "fare", "split_mode", "payer", "passengers"]


def parse_passengers(text: str) -> list:
    """'Asha:2;Ben:1' -> passengers. The value after ':' is optional."""
    out = []
    for chunk in str(text).split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        name, _, val = chunk.partition(":")
        value = parse_number(val, field=f"Value for {name.strip()}") if val.strip() else None
        out.append(Passenger(name=name.strip(), value=value))
    return out


def import_csv_text(text: str):
    """Returns (rides, errors). errors is a list of {'row': int, 'error': str}."""
    rides, errors = [], []
    reader = csv.DictReader(io.StringIO(text))
    missing = [c for c in REQUIRED if c not in (reader.fieldnames or [])]
    if missing:
        return [], [{"row": 1, "error": f"Missing required column(s): {', '.join(missing)}."}]
    for row in reader:
        line = reader.line_num
        try:
            rides.append(build_ride(
                date=row.get("date", ""), route=row.get("route", ""), category=row.get("category", ""),
                fare=row.get("fare", ""), extras=row.get("extras", "") or "",
                split_mode=row.get("split_mode", ""), payer=row.get("payer", ""),
                passengers=parse_passengers(row.get("passengers", "")),
                settled_names=[s.strip() for s in (row.get("settled") or "").split(";") if s.strip()],
                notes=row.get("notes", "") or ""))
        except ValidationError as exc:
            errors.append({"row": line, "error": str(exc)})
    return rides, errors


def import_csv_file(path):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        return import_csv_text(fh.read())
