"""Input validators. Every function raises ValidationError with a message a user can act on."""
from __future__ import annotations

import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from .models import (CATEGORIES, MAX_FARE_CENTS, MAX_PASSENGERS, MIN_PASSENGERS,
                     MODES, CURRENCY, money)


class ValidationError(ValueError):
    pass


def parse_money(text, *, field="Amount", allow_zero=False, allow_blank=False) -> int:
    """'1,250.50' -> 125050 cents. Rejects text, negatives, >2 decimals, absurd values."""
    s = str(text).strip().replace(",", "").replace(CURRENCY, "").replace("$", "")
    if not s:
        if allow_blank:
            return 0
        raise ValidationError(f"{field} is required.")
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise ValidationError(f"{field} must be a number like 250 or 250.50 (got '{text}').")
    if not d.is_finite():
        raise ValidationError(f"{field} must be a normal number.")
    if d.as_tuple().exponent < -2:
        raise ValidationError(f"{field} can have at most 2 decimal places.")
    if d < 0:
        raise ValidationError(f"{field} cannot be negative.")
    if d == 0 and not allow_zero:
        raise ValidationError(f"{field} must be greater than 0.")
    cents = int(d * 100)
    if cents > MAX_FARE_CENTS:
        raise ValidationError(f"{field} cannot exceed {money(MAX_FARE_CENTS)}.")
    return cents


def parse_number(text, *, field="Value") -> float:
    s = str(text).strip()
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise ValidationError(f"{field} must be a number (got '{text}').")
    if not d.is_finite():
        raise ValidationError(f"{field} must be a normal number.")
    return float(d)


def parse_date(text) -> str:
    s = str(text).strip()
    try:
        d = datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        raise ValidationError("Date must look like 2026-11-25 (year-month-day).")
    if d > date.today():
        raise ValidationError("Date cannot be in the future.")
    if d.year < 2000:
        raise ValidationError("Date must be 2000 or later.")
    return d.isoformat()


def parse_text(text, *, field, max_len=80, allow_blank=False) -> str:
    s = re.sub(r"\s+", " ", str(text)).strip()
    if not s and not allow_blank:
        raise ValidationError(f"{field} is required.")
    if len(s) > max_len:
        raise ValidationError(f"{field} must be {max_len} characters or fewer.")
    return s


def parse_category(text) -> str:
    s = str(text).strip().lower()
    if s not in CATEGORIES:
        raise ValidationError(f"Category must be one of: {', '.join(CATEGORIES)}.")
    return s


def parse_mode(text) -> str:
    s = str(text).strip().lower()
    if s not in MODES:
        raise ValidationError(f"Split mode must be one of: {', '.join(MODES)}.")
    return s


def validate_passengers(mode: str, passengers: list, total_cents: int) -> None:
    n = len(passengers)
    if not MIN_PASSENGERS <= n <= MAX_PASSENGERS:
        raise ValidationError(f"A ride needs {MIN_PASSENGERS} to {MAX_PASSENGERS} passengers (got {n}).")
    seen = set()
    for p in passengers:
        name = p.name.strip()
        if not name:
            raise ValidationError("Every passenger needs a name.")
        if len(name) > 40:
            raise ValidationError(f"Name '{name[:15]}...' is longer than 40 characters.")
        if name.lower() in seen:
            raise ValidationError(f"'{name}' appears twice. Names must be unique within a ride.")
        seen.add(name.lower())

    if mode == "equal":
        return
    if mode == "weighted":
        for p in passengers:
            if p.value is None or not 0 < p.value <= 100:
                raise ValidationError(f"{p.name}: shares must be a number above 0 and up to 100.")
    elif mode == "percent":
        for p in passengers:
            if p.value is None or not 0 < p.value <= 100:
                raise ValidationError(f"{p.name}: percent must be above 0 and up to 100.")
        total = sum(Decimal(str(p.value)) for p in passengers)
        if total != 100:
            raise ValidationError(f"Percentages add up to {total}, they must add up to 100.")
    elif mode == "fixed":
        fixed_total = 0
        flexible = 0
        for p in passengers:
            if p.value is None:
                flexible += 1
                continue
            d = Decimal(str(p.value))
            if d < 0 or d.as_tuple().exponent < -2:
                raise ValidationError(f"{p.name}: fixed amount must be 0 or more with at most 2 decimals.")
            fixed_total += int(d * 100)
        if fixed_total > total_cents:
            raise ValidationError(f"Fixed amounts ({money(fixed_total)}) exceed the ride total ({money(total_cents)}).")
        if flexible == 0 and fixed_total != total_cents:
            raise ValidationError(
                f"Fixed amounts add up to {money(fixed_total)} but the ride total is {money(total_cents)}. "
                "Leave one person's amount blank to let them cover the rest.")
