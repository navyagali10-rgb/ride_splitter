"""Data structures shared by the CLI and the web UI. Money is stored as integer cents."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "data" / "rides.json"
SAMPLE_CSV = BASE_DIR / "data" / "sample_rides.csv"
EXPORT_DIR = BASE_DIR / "exports"

CURRENCY = "₹"
MODES = ("equal", "weighted", "percent", "fixed")
CATEGORIES = ("commute", "airport", "event", "leisure", "office", "other")
MAX_FARE_CENTS = 5_000_000          # 50,000.00
MIN_PASSENGERS, MAX_PASSENGERS = 2, 10


def money(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    c = abs(int(cents))
    return f"{sign}{CURRENCY}{c // 100:,}.{c % 100:02d}"


@dataclass
class Passenger:
    name: str
    value: Optional[float] = None   # weight, percent, or fixed amount depending on mode
    share_cents: int = 0
    settled: bool = False


@dataclass
class Ride:
    id: int
    date: str                        # ISO yyyy-mm-dd
    route: str
    category: str
    fare_cents: int
    extras_cents: int                # tips, tolls, fees
    split_mode: str
    payer: str                       # who paid the driver
    passengers: list
    notes: str = ""

    @property
    def total_cents(self) -> int:
        return self.fare_cents + self.extras_cents

    @property
    def unsettled_cents(self) -> int:
        return sum(p.share_cents for p in self.passengers
                   if not p.settled and p.name != self.payer)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Ride":
        pax = [Passenger(name=str(p["name"]),
                         value=None if p.get("value") is None else float(p["value"]),
                         share_cents=int(p["share_cents"]),
                         settled=bool(p.get("settled", False)))
               for p in d["passengers"]]
        return cls(id=int(d["id"]), date=str(d["date"]), route=str(d["route"]),
                   category=str(d["category"]), fare_cents=int(d["fare_cents"]),
                   extras_cents=int(d["extras_cents"]), split_mode=str(d["split_mode"]),
                   payer=str(d["payer"]), passengers=pax, notes=str(d.get("notes", "")))
